# main.py
import os

from app import app
from db_setup import init_db, db_session
from forms import ContactSearchForm, PersonForm
from flask import flash, render_template, request, redirect
from models import Location, Person
from tables import Results

init_db()


@app.route('/', methods=['GET', 'POST'])
def index():
    search = ContactSearchForm(request.form)
    if request.method == 'POST':
        return search_results(search)

    return render_template('index.html', form=search)


@app.route('/results')
def search_results(search):
    results= []
    search_string = search.data['search']

    if search_string:
        if search.data['select'] == 'Location':
            qry = db_session.query(Person, Location).filter(
                Location.id==Person.location_id).filter(
                    Location.city_country.contains(search_string))
            results = [item[0] for item in qry.all()]
        elif search.data['select'] == 'Full Name':
            qry = db_session.query(Person).filter(
                Person.full_name.contains(search_string))
            results = qry.all()
        elif search.data['select'] == 'Connected Event':
            qry = db_session.query(Person).filter(
                Person.connected_event.contains(search_string))
            results = qry.all()
        elif search.data['select'] == 'Birthday':
            qry = db_session.query(Person).filter(
                Person.birthday.contains(search_string))
        else:
            qry = db_session.query(Person)
            results = qry.all()
    else:
        qry = db_session.query(Person)
        results = qry.all()

    if not results:
        flash('No results found!')
        return redirect('/')
    else:
        # display results
        table = Results(results)
        table.border = True
        return render_template('results.html', table=table)


@app.route('/new_person', methods=['GET','POST'])
def new_person():
    """
    Add a new person
    """
    form = PersonForm(request.form)

    if request.method == 'POST' and form.validate():
        # save the person
        person = Person()
        save_changes(person, form, new=True)
        flash('Person created successfully!')
        return redirect('/')

    return render_template('new_person.html', form=form)


@app.route('/item/<int:id>', methods=['GET', 'POST'])
def edit(id):
    qry = db_session.query(Person).filter(Person.id==id)
    person = qry.first()

    if person:
        form = PersonForm(formdata=request.form, obj=person)
        if request.method == 'POST' and form.validate():
            # save edits
            save_changes(person, form)
            flash('Person updated successfully!')
            return redirect('/')
        return render_template('edit_person.html', form=form)
    else:
        return 'Error loading #{id}'.format(id=id)


@app.route('/delete/<int:id>', methods=['GET', 'POST'])
def delete(id):
    """
    Delete the item in teh database that matches the specified id in the URL
    """
    qry = db_session.query(Person).filter(
        Person.id==id)
    person = qry.first()

    if person:
        form = PersonForm(formdata=request.form, obj=person)
        if request.method == 'POST' and form.validate():
            # delete the item from the database
            db_session.delete(person)
            db_session.commit()

            flash('Person deleted successfully!')
            return redirect('/')
        return render_template('delete_person.html', form=form)
    else:
        return 'Error deleting #{id}'.format(id=id)


if __name__ == '__main__':
    app.run()


def save_changes(person, form, new=False):
    """
    Save the changes to the database
    """
    # Get data from form and assign it to the correct attributes
    # of the SQLAlchemy table object
    location = Location()
    location.city_country = form.location.data

    person.location = location
    person.full_name = form.full_name.data
    person.connected_date = form.connected_date.data
    person.connected_event = form.connected_event.data
    person.phone_region = form.phone_region.data
    person.phone_number = form.phone_number.data
    person.email = form.email.data
    person.wechat = form.wechat.data
    person.birthday = form.birthday.data

    if new:
        # Add the new person to the database
        db_session.add(person)

    # commit the data to the database
    db_session.commit()
