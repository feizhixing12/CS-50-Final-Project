""""""
How to Run this Project:

    1. Change directory to /contactdb/ on IDE
    2. run this command "FLASK_APP=main.py flask run"
    3. Click on the link behind "* Running on https://"

    A webpage with yellow background shall pop up. That is my online contact database!

""""""
What Is This Project?

    This is an online database storing the contact information of people that I treasure.

""""""
What Features Does It Have?

    1. New contacts can be added
        Simply click on the "Add" button on the homepage.
        An Add page will appear.
        Fill in however many blanks, and then hit the "Add" button on that page.
    2. Contacts can be found by a keyword in a criteria
        Select the search criteria in the draw-down menu on the homepage, type the keyword into the text box, and then click the "Search" button.
        The keyword can be a whole or partial word.
        If no contacts contains the keyword in the selected criteria, the page will stay at the homepage, and a "No results found!" message will appear.
    3. Cotacts can be filtered by a keyword in a criteria
        If multiple contacts contains the searched keyword in the selected criteria, all these contacts will be displayed on the following results page.
    4. All recorded contacts can be displayed
        Simply click on the "Search" button withou typing in any keyword. All contacts will appear on the following results page.
    5. Any fields of any contacts can be edited.
        On the results page, click on the "Edit" link for any entry, and an edit page will appear.
        The current information will be pre-filled for each blank.
        Simply change however many fields, click "Update," then the edits will be saved.
        To view the changed results again, click "Search" without typing keywords on the homepage.
    6. Any entries can be deleted
        On the results page, click on the "Delete" link for any entries that you wish to delete
        The page will be redirected to the homepage with a message indicating successful deletion.

""""""
Link to the 2-min Video:

    https://youtu.be/NwzfPoqFM_4