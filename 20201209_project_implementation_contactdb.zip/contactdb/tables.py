# tables.py

from flask_table import Table, Col, LinkCol

class Results(Table):
    id = Col('Id', show=False)
    location = Col('Location')
    full_name = Col('Full Name')
    connected_date = Col('Connected Date')
    connected_event = Col('Connected Event')
    phone_region = Col('Phone Region')
    phone_number = Col('Phone Number')
    email = Col('Email')
    wechat = Col('WeChat')
    birthday = Col('Birthday (MM/DD/YYYY)')
    edit = LinkCol('Edit', 'edit', url_kwargs=dict(id='id'))
    delete = LinkCol('Delete', 'delete', url_kwargs=dict(id='id'))