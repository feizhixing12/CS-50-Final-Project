""""""
How I Implemented My Project?

I. Background

    1. I started with Flask and an SQL database
    2. Because Flask is a micro-web-framework, it does not have an Object Relational Mapper (ORM).
    3. To add database interactivity, I added an extension called "Flask-SQLAlchemy," made by SQLAlchemy for Flask.


II. Create a Database in Flask

    4. To create databases in SQLAlchemy, I used the "db_creator.py" to create classes that model the database itself.
        The "class" inside mirrors "tables" in SQL.
        This file creates a .db file to build upon.
    5. I made a file called "app.py" to create a simple application script.
        In this file, I created a Flask app object and told it where the SQLAlchemy database should reside.
        I created a db object that allows me to integerate SQLAlchemy into Flask.
    6. I created file "models.py" to create the real database using the db object.
    7. To initiate the database in Flask, I made file "db_setup.py" which will be imported to "main.py," the main application.

III. Add Forms to Flask

    8. To create forms in Flask, I installed another extension called "Flask-WTF."
    9. In file "forms.py," using the modules from WTForms, I created the Search form and Add New Contact form.
    10. Because Flask-WTF recommends creating a template with a macro called "_formhelpers.html," I made a file with that name to feed the form information into various .html pages.

IV. Add Table to Flask

    11. To display data on the webpage neatly, I added another extension called "Flask Table."
    12. Then using the extension's existin module, I listed the criteria to be displayed for a serach result page.
    13. Therefore, the entire result table can be refereced as a block "Results" in "main.py."

V. Other Functions

    14. A result page is created under "results.html" to display the result table.
    15. "new_person.html," "edit_person.html," and "delete_person.html" each corresponds to a separate webpage with the functio that the file names suggest.
