# db_creator.py

from sqlalchemy import create_engine, ForeignKey
from sqlalchemy import Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, backref

engine = create_engine('sqlite:///mycontact.db', echo=True)
Base = declarative_base()


class Location(Base):
    __tablename__ = "locations"

    id = Column(Integer, primary_key=True)
    city_country = Column(String)

    def __repr__(self):
        return "{}".format(self.city_country)


class Person(Base):
    """"""
    __tablename__ = "persons"

    id = Column(Integer, primary_key=True)
    full_name = Column(String)
    connected_date = Column(String)
    connected_event = Column(String)
    phone_region = Column(String)
    phone_number = Column(String)
    email = Column(String)
    wechat = Column(String)
    birthday = Column(String)

    location_id = Column(Integer, ForeignKey("locations.id"))
    location = relationship("Location", backref=backref(
        "persons", order_by=id))

# create table
Base.metadata.create_all(engine)