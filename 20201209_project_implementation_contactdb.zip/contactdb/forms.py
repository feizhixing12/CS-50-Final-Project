# forms.py

from wtforms import Form, StringField, SelectField

class ContactSearchForm(Form):
    choices = [('Location', 'Location'),
               ('Full Name', 'Full Name'),
               ('Connected Event', 'Connected Event'),
               ('Birthday', 'Birthday (MM/DD/YYYY)')
               ]
    select = SelectField('Search for Contact:', choices=choices)
    search = StringField('')


class PersonForm(Form):
    phone_regions = [('United States', 'United States (+1)'),
                   ('China', 'China (+86)'),
                   ('Hong Kong', 'Hong Kong (+852)')
                   ]
    location = StringField('Location')
    full_name = StringField('Full Name')
    connected_date = StringField('Connected Date')
    connected_event = StringField('Connected Event')
    phone_region = SelectField('Phone Region', choices=phone_regions)
    phone_number = StringField('Phone Number')
    email = StringField('Email')
    wechat = StringField('WeChat')
    birthday = StringField('Birthday (MM/DD/YYYY)')
