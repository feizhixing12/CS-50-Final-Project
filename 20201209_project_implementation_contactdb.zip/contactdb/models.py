# models.py

from app import db


class Location(db.Model):
    __tablename__ = "locations"

    id = db.Column(db.Integer, primary_key=True)
    city_country = db.Column(db.String)

    def __repr__(self):
        return "{}".format(self.city_country)


class Person(db.Model):
    """"""
    __tablename__ = "persons"

    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String)
    connected_date = db.Column(db.String)
    connected_event = db.Column(db.String)
    phone_region = db.Column(db.String)
    phone_number = db.Column(db.String)
    email = db.Column(db.String)
    wechat = db.Column(db.String)
    birthday = db.Column(db.String)

    location_id = db.Column(db.Integer, db.ForeignKey("locations.id"))
    location = db.relationship("Location", backref=db.backref(
        "persons", order_by=id), lazy=True)